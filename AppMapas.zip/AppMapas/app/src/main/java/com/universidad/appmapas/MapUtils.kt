package com.universidad.appmapas.ui.screens

import android.content.Context
import android.location.Geocoder
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

// Función para obtener la ubicación actual del dispositivo mediante el GPS
fun obtenerUbicacionActual(context: Context, onLocationReceived: (LatLng) -> Unit) {
    try {
        val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                onLocationReceived(LatLng(location.latitude, location.longitude))
            }
        }
    } catch (e: SecurityException) {
        e.printStackTrace()
    }
}

// Función de Geocodificación para transformar texto en coordenadas geográficas (Lat, Lng)
suspend fun buscarLugarPorNombre(
    context: Context,
    query: String,
    onResult: (LatLng?, String?) -> Unit
) {
    withContext(Dispatchers.IO) {
        try {
            val geocoder = Geocoder(context, Locale.getDefault())
            val addresses = geocoder.getFromLocationName(query, 1)
            if (!addresses.isNullOrEmpty()) {
                val address = addresses[0]
                val latLng = LatLng(address.latitude, address.longitude)
                withContext(Dispatchers.Main) {
                    onResult(latLng, address.featureName ?: address.getAddressLine(0))
                }
            } else {
                withContext(Dispatchers.Main) {
                    onResult(null, null)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            withContext(Dispatchers.Main) {
                onResult(null, null)
            }
        }
    }
}